import joblib
import numpy as np

# Model ve scaler yükle
model = joblib.load("data/diabetes_model.pkl")
scaler = joblib.load("data/scaler.pkl")

# Yeni hasta verisi (örnek)
new_patient = np.array([[6, 148, 72, 35, 0, 33.6, 0.627, 50]])
new_patient_scaled = scaler.transform(new_patient)

# Tahmin
prediction = model.predict(new_patient_scaled)
print("Diyabet riski:", "Pozitif" if prediction[0] == 1 else "Negatif")
