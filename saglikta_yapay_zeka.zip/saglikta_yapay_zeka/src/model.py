import joblib
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report

# Ön işlenmiş veriyi yükle
X_train_scaled, X_test_scaled, y_train, y_test = joblib.load("data/processed_data.pkl")

# Modeli oluştur ve eğit
model = LogisticRegression()
model.fit(X_train_scaled, y_train)

# Tahmin ve değerlendirme
y_pred = model.predict(X_test_scaled)
print("Doğruluk:", accuracy_score(y_test, y_pred))
print(classification_report(y_test, y_pred))

# Modeli kaydet
joblib.dump(model, "data/diabetes_model.pkl")
print("Model kaydedildi.")
