# Sağlıkta Yapay Zeka: Diyabet Tahmin Modeli

Bu proje, Pima Indians Diabetes veri seti kullanarak diyabet tahmini yapan bir yapay zeka uygulamasıdır. Proje, veri ön işleme, model eğitimi ve yeni hasta verileri için tahmin adımlarını içerir. Proje GitHub üzerinde paylaşılmaya hazırdır.

## 📂 Proje Yapısı

```
saglikta-yapay-zeka/
│
├── data/
│   └── diabetes.csv        # Pima Indians Diabetes veri seti
├── notebooks/
│   ├── 01_veri_onisleme.ipynb
│   ├── 02_model_egitimi.ipynb
│   └── 03_tahmin_demo.ipynb
├── src/
│   ├── preprocessing.py    # Veri temizleme & scaling
│   ├── model.py            # Model eğitimi ve kaydetme
│   └── predict.py          # Yeni veri tahmini
├── requirements.txt
├── README.md
└── LICENSE
```
